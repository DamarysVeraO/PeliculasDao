package conn.util;

public class Util {
	  public static String URL = "jdbc:postgresql://localhost:5432/poo";
	  public static String USUARIO = "postgres";
	  public static String CLAVE = "1234";

}
