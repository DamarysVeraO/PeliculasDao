package com.gestion_peliculas.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gestion_peliculas.entity.Actor;
import com.gestion_peliculas.entity.Genero;

import conn.util.Util;

public class GeneroDAOImpl implements GeneroDAO{

	public void ingresar(Genero genero) {
		String query ="INSERT INTO public.genero(id, nombre)VALUES ( ?, ?);";
		Connection conn;
		try
	       {
		   conn = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
		   		 

			PreparedStatement stm = conn.prepareStatement(query);  
			stm.setInt(1, genero.getId());
			stm.setString(2, genero.getNombre());
		
		
			stm.execute();
			   
		   }
		   	   
	   catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}

	public void modificar(Genero genero) {
		String query = "UPDATE public.genero SET  nombre=? WHERE id=?;";
		
		 Connection conn;
		try
	       {
		   conn = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
		   		 

			PreparedStatement stm = conn.prepareStatement(query);  
			stm.setString(1, genero.getNombre());
			stm.setInt(3, genero.getId());
			stm.execute();
			   
		   }
		   	   
	   catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}

	public Genero getGenero(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Genero> getGenero() {
		List<Genero> generos = new ArrayList<Genero>(); 
		Connection con; 
	        
         try 
       {
           con = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
           
           
      
           String sql = "SELECT id, nombre FROM Genero";
           
           PreparedStatement stm = con.prepareStatement(sql);
           ResultSet rs = stm.executeQuery();
           while(rs.next()){
              Genero genero = new Genero(rs.getInt(1), rs.getString(2));
             generos.add(genero) ;        
            }       
           
       }   
         catch (SQLException e) 
         
       {
       	 e.printStackTrace();
       }	
		
		
		
		return generos;
	
	}

}
