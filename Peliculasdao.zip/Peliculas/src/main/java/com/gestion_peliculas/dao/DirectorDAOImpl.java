package com.gestion_peliculas.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gestion_peliculas.entity.Actor;
import com.gestion_peliculas.entity.Director;

import conn.util.Util;

public class DirectorDAOImpl implements DirectorDAO {

	public void ingresar(Director director) {
		String query ="INSERT INTO public.director(id, nombre, apellido)VALUES ( ?, ?, ?);";
		Connection conn;
		try
	       {
		   conn = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
		   		 

			PreparedStatement stm = conn.prepareStatement(query);  
			stm.setInt(1, director.getId());
			stm.setString(2, director.getNombre());
			stm.setString(3, director.getApellido());
		
			stm.execute();
			   
		   }
		   	   
	   catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}

	public void modificar(Director director) {
		String query = "UPDATE public.director SET  nombre=? WHERE id=?;";
		
		 Connection conn;
		try
	       {
		   conn = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
		   		 

			PreparedStatement stm = conn.prepareStatement(query);  
			stm.setString(1, director.getNombre());
			stm.setString(2, director.getApellido());
			stm.setInt(3, director.getId());
			stm.execute();
			   
		   }
		   	   
	   catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}

	public Director getDirector(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Director> getDirector() {
		List<Director> directores = new ArrayList<Director>(); 
		Connection con; 
	        
         try 
       {
           con = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
           
           
      
           String sql = "SELECT id, nombre, apellido FROM Director";
           
           PreparedStatement stm = con.prepareStatement(sql);
           ResultSet rs = stm.executeQuery();
           while(rs.next()){
              Director director = new Director(rs.getInt(1), rs.getString(2), rs.getString(3));
              directores.add(director);        
            }       
           
       }   
         catch (SQLException e) 
         
       {
       	 e.printStackTrace();
       }	
		
		
		
		return directores;
	}

}