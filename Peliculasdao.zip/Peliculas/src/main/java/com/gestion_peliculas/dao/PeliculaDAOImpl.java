package com.gestion_peliculas.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gestion_peliculas.entity.Actor;
import com.gestion_peliculas.entity.Pelicula;

import conn.util.Util;

public class PeliculaDAOImpl implements PeliculaDAO {

	public void ingresar(Pelicula pelicula) {
		String query ="INSERT INTO public.peliculas(id, titulo, rating)VALUES ( ?, ?);";
		Connection conn;
		try
	       {
		   conn = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
		   		 

			PreparedStatement stm = conn.prepareStatement(query);  
			stm.setInt(1, pelicula.getId());
			stm.setString(2, pelicula.getTitulo());
			stm.setInt(3, pelicula.getRating());
			stm.execute();
			   
		   }
		   	   
	   catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}

	public void modificar(Pelicula pelicula) {
		String query = "UPDATE public.pelicula SET  nombre=? WHERE id=?;";
		
		 Connection conn;
		try
	       {
		   conn = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
		   		 

			PreparedStatement stm = conn.prepareStatement(query);  
			stm.setInt(1, pelicula.getId());
			stm.setString(2, pelicula.getTitulo());
			stm.setInt(3, pelicula.getRating());
			stm.execute();
			   
		   }
		   	   
	   catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}

	public Pelicula getPelicula(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Pelicula> getPeliculas() {
		List<Pelicula> peliculas = new ArrayList<Pelicula>(); 
		Connection con; 
	        
         try 
       {
           con = DriverManager.getConnection(Util.URL, Util.USUARIO, Util.CLAVE);
           
           
      
           String sql = "SELECT id, titulo, rating FROM Pelicula";
           
           PreparedStatement stm = con.prepareStatement(sql);
           ResultSet rs = stm.executeQuery();
           while(rs.next()){
              Pelicula pelicula = new Pelicula(rs.getInt(1), rs.getString(2),rs.getInt(3) );
              peliculas.add(pelicula) ;        
            }       
           
       }   
         catch (SQLException e) 
         
       {
       	 e.printStackTrace();
       }	
		
		
		
		return peliculas;	

}
}
